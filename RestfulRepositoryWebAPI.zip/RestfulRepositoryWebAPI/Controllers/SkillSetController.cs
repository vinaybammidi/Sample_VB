﻿using DataAccess.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace RestfulRepositoryWebAPI.Controllers
{
    public class SkillSetController : ApiController
    {
        ISkillSetService _skillSetService;

        public SkillSetController()
        {

        }
        public SkillSetController(ISkillSetService skillSetService)
        {
            _skillSetService = skillSetService;
        }
        public async Task<IHttpActionResult> GetAllSkillSetByPageIndex()
        {
            var resultData = await _skillSetService.GetAllSkillSetByPageIndex(1, 1);
            if (resultData == null)
            {
                return NotFound();
            }
            //return Ok(resultData);
            return Json(resultData);
        }
    }
}
