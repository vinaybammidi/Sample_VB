﻿using DataAccess.Entities;
using DataAccess.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Services
{
    public class SkillSetService: ISkillSetService
    {
        IUnitOfWork _unitOfWork;
        public SkillSetService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public async Task<IEnumerable<SkillAssessment>> GetAllSkillSetByPageIndex(int pageIndex, int pageSize)
        {
            return await _unitOfWork.SkillSetRepository.GetAllSkillSetByPageIndex(pageIndex, pageSize);
        }
    }
}
