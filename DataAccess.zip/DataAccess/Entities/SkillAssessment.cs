﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Entities
{
    
    public class SkillAssessment
    {
        public string SkillSet { get; set; }
        public int SkilledCount { get; set; }
        public string Developers { get; set; }       

    }
}
