﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Assessment_MVC.Startup))]
namespace Assessment_MVC
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
